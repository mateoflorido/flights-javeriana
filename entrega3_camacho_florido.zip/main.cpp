#include "Console.h"

int main() {
  Console console("$ ");
  console.run();

  return 0;
}